#####  Created by:
#####  Bridge Commander Universal Tool


import App
import Foundation


Foundation.SoundDef("sfx/Weapons/N_32c_Refit_Array_A.wav", "32c_Refit_Array Start", 1)
Foundation.SoundDef("sfx/Weapons/N_32c_Refit_Array_B.wav", "32c_Refit_Array Loop", 1)
