#####  Created by:
#####  Bridge Commander Universal Tool


import App
import Foundation


Foundation.SoundDef("sfx/Weapons/N_32nd_Century_phaser.wav", "32c_Phaser Start", 1)
Foundation.SoundDef("sfx/Weapons/N_32nd_Century_phaser.wav", "32c_Phaser Loop", 1)
