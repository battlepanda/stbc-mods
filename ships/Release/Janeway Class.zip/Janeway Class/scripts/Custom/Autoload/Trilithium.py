#####  Created by:
#####  Bridge Commander Universal Tool


import App
import Foundation


Foundation.SoundDef("sfx/Weapons/Trilithium Torpedo.wav", "Trilithium", 1)
