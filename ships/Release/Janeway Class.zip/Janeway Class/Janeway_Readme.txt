ALL CREDITS GO TO***

- "That Guy...Brian" for extracting the model from sto and compatibilizing it into bridge commander (he stated there is no way to fix the damage model unfortunately)

- "Tardis" for figuring out and fixing some impossible technology problems and glitches that are now fixed

- me (narrowcwyfe) for making the hardpoint and all sound related aspects of this ship

*** please do not alter this ship without my permission first





INSTALLING THIS MOD

- to install this ship simply copy and past the data, scripts, and sfx folders into your STBC directory


*** replace all files in order for this ship to be proper




REQUIREMENTS

- it works on stock but it is recommended you run this ship on a Kobayashi Maru install




CONTACTS

- you can contact me by following me on twitter (Hexagonal_Nexul) or adding me on discord (narrowcwyfe#0007)