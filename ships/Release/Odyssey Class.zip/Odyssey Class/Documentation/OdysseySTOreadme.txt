ALL CREDITS GO TO***

- "That Guy...Brian" for extracting the model from sto and compatibilizing it into bridge commander
- me (narrowcwyfe) for making the hardpoint and all sound related aspects of this ship
*** please do not alter this ship without my permission first

INSTALLING THIS MOD
- to install this ship simply copy and past the data, scripts, Documentation, and sfx folders into your STBC directory 
***please use the 7 zip tool, winrar can mess things up***
*** replace all files in order for this ship to be proper!

REQUIREMENTS
- Use Kobayashi Maru (any other mod or or the stock game might not have required technologies)

CONTACTS
- you can contact me by following me on twitter (Hexagonal_Nexul) or adding me on discord (narrowcwyfe#0007)