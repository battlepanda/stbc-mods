#######################################################################################
#  Custom Weapon Sound Plugin                                                         #
#  Created by BC - Mod Packager                                                       #
#  Date: 4/10/2002                                                                    #
#######################################################################################
#                                                                                     #
import Foundation
import App
#                                                                                     #
#######################################################################################
#                                                                                     #
Foundation.SoundDef("sfx/Weapons/MkXVIII_Phaser_a.wav", "MkXVIII_Phaser Start", 1)
Foundation.SoundDef("sfx/Weapons/MkXVIII_Phaser_b.wav", "MkXVIII_Phaser Loop", 1)
Foundation.SoundDef("sfx/Weapons/nemesis2.wav", "nemesisQuantum", 1)
Foundation.SoundDef("sfx/Weapons/Photon02JLH.wav", "Photon2TorpSound", 1)
#                                                                                     #
#######################################################################################
